using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SignalFlowMini
{
    internal static class Native
    {
        public const int WH_KEYBOARD_LL = 13;
        public const int WM_KEYDOWN = 0x0100;
        public const int WM_KEYUP = 0x0101;
        public const int WM_SYSKEYDOWN = 0x0104;
        public const int WM_SYSKEYUP = 0x0105;
        public const int VK_F8 = 0x77;
        public const uint WM_PASTE = 0x0302;
        public const uint SMTO_ABORTIFHUNG = 0x0002;
        public const uint INPUT_KEYBOARD = 1;
        public const uint KEYEVENTF_KEYUP = 0x0002;
        public const ushort VK_CONTROL = 0x11;
        public const ushort VK_V = 0x56;
        public const uint WIM_DATA = 0x3C0;
        public const uint CALLBACK_FUNCTION = 0x00030000;
        public const uint WAVE_FORMAT_PCM = 1;

        public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
        public delegate void WaveInProc(IntPtr hwi, uint uMsg, UIntPtr dwInstance, IntPtr dwParam1, IntPtr dwParam2);

        [StructLayout(LayoutKind.Sequential)]
        public struct KBDLLHOOKSTRUCT
        {
            public uint vkCode;
            public uint scanCode;
            public uint flags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct WAVEFORMATEX
        {
            public ushort wFormatTag;
            public ushort nChannels;
            public uint nSamplesPerSec;
            public uint nAvgBytesPerSec;
            public ushort nBlockAlign;
            public ushort wBitsPerSample;
            public ushort cbSize;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct WAVEHDR
        {
            public IntPtr lpData;
            public uint dwBufferLength;
            public uint dwBytesRecorded;
            public UIntPtr dwUser;
            public uint dwFlags;
            public uint dwLoops;
            public IntPtr lpNext;
            public UIntPtr reserved;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct GUITHREADINFO
        {
            public int cbSize;
            public uint flags;
            public IntPtr hwndActive;
            public IntPtr hwndFocus;
            public IntPtr hwndCapture;
            public IntPtr hwndMenuOwner;
            public IntPtr hwndMoveSize;
            public IntPtr hwndCaret;
            public System.Drawing.Rectangle rcCaret;
        }

        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetGUIThreadInfo(uint idThread, ref GUITHREADINFO lpgui);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool IsWindow(IntPtr hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam, uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT
        {
            public uint type;
            public InputUnion U;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct InputUnion
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
            [FieldOffset(0)] public HARDWAREINPUT hi;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public UIntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct HARDWAREINPUT
        {
            public uint uMsg;
            public ushort wParamL;
            public ushort wParamH;
        }

        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [DllImport("winmm.dll")]
        public static extern uint waveInOpen(out IntPtr phwi, uint uDeviceID, ref WAVEFORMATEX pwfx, WaveInProc dwCallback, UIntPtr dwInstance, uint fdwOpen);

        [DllImport("winmm.dll")]
        public static extern uint waveInPrepareHeader(IntPtr hwi, IntPtr pwh, uint cbwh);

        [DllImport("winmm.dll")]
        public static extern uint waveInUnprepareHeader(IntPtr hwi, IntPtr pwh, uint cbwh);

        [DllImport("winmm.dll")]
        public static extern uint waveInAddBuffer(IntPtr hwi, IntPtr pwh, uint cbwh);

        [DllImport("winmm.dll")]
        public static extern uint waveInStart(IntPtr hwi);

        [DllImport("winmm.dll")]
        public static extern uint waveInStop(IntPtr hwi);

        [DllImport("winmm.dll")]
        public static extern uint waveInReset(IntPtr hwi);

        [DllImport("winmm.dll")]
        public static extern uint waveInClose(IntPtr hwi);
    }

    internal sealed class AudioRecorder : IDisposable
    {
        private const int BytesPerSecond = 32000; // 16 kHz mono PCM16
        private const int PreRollMilliseconds = 500;
        private const int PreRollBytes = BytesPerSecond * PreRollMilliseconds / 1000;
        private const int BufferMilliseconds = 100;
        private const int BufferBytes = BytesPerSecond * BufferMilliseconds / 1000;

        private readonly object _gate = new object();
        private readonly MemoryStream _pcm = new MemoryStream();
        private readonly byte[] _preRoll = new byte[PreRollBytes];
        private readonly List<BufferSlot> _slots = new List<BufferSlot>();
        private readonly Native.WaveInProc _callback;
        private IntPtr _waveIn;
        private bool _monitoring;
        private bool _capturing;
        private bool _disposed;
        private bool _nativeCleanupFailed;
        private int _preRollWrite;
        private int _preRollCount;

        private sealed class BufferSlot
        {
            public IntPtr Data;
            public IntPtr Header;
        }

        public AudioRecorder()
        {
            _callback = WaveInCallback; // rooted for recorder lifetime; retained if native cleanup fails.
        }

        public void StartMonitor()
        {
            lock (_gate)
            {
                if (_disposed) throw new ObjectDisposedException("AudioRecorder");
                if (_monitoring) return;

                var fmt = new Native.WAVEFORMATEX
                {
                    wFormatTag = (ushort)Native.WAVE_FORMAT_PCM,
                    nChannels = 1,
                    nSamplesPerSec = 16000,
                    wBitsPerSample = 16,
                    nBlockAlign = 2,
                    nAvgBytesPerSec = BytesPerSecond,
                    cbSize = 0
                };

                uint mm = Native.waveInOpen(out _waveIn, 0xFFFFFFFF, ref fmt, _callback, UIntPtr.Zero, Native.CALLBACK_FUNCTION);
                if (mm != 0) throw new InvalidOperationException("Microphone open failed (winmm " + mm + ").");

                try
                {
                    // Short buffers reduce capture-boundary latency and keep the rolling
                    // pre-roll fresh enough to preserve the first syllable after F8 goes down.
                    for (int i = 0; i < 8; i++) AddBuffer(BufferBytes);
                    _monitoring = true;
                    mm = Native.waveInStart(_waveIn);
                    if (mm != 0) throw new InvalidOperationException("Microphone start failed (winmm " + mm + ").");
                }
                catch
                {
                    _monitoring = false;
                    // StartMonitor holds _gate here. Do not call waveInStop/reset while
                    // holding it because winmm may synchronously callback into _gate.
                    SafeNativeClose(false);
                    throw;
                }
            }
        }

        public void BeginCapture()
        {
            lock (_gate)
            {
                if (_disposed) throw new ObjectDisposedException("AudioRecorder");
                if (!_monitoring) throw new InvalidOperationException("Microphone monitor is not running.");
                if (_capturing) return;

                _pcm.SetLength(0);
                CopyPreRollTo(_pcm);
                _capturing = true;
            }
        }

        public byte[] EndCapture()
        {
            lock (_gate)
            {
                if (!_capturing) return new byte[0];
                _capturing = false;
                return _pcm.ToArray();
            }
        }

        private void AddBuffer(int bytes)
        {
            var slot = new BufferSlot();
            slot.Data = Marshal.AllocHGlobal(bytes);
            var hdr = new Native.WAVEHDR { lpData = slot.Data, dwBufferLength = (uint)bytes };
            slot.Header = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Native.WAVEHDR)));
            Marshal.StructureToPtr(hdr, slot.Header, false);
            uint mm = Native.waveInPrepareHeader(_waveIn, slot.Header, (uint)Marshal.SizeOf(typeof(Native.WAVEHDR)));
            if (mm != 0) throw new InvalidOperationException("Audio buffer prepare failed (winmm " + mm + ").");
            mm = Native.waveInAddBuffer(_waveIn, slot.Header, (uint)Marshal.SizeOf(typeof(Native.WAVEHDR)));
            if (mm != 0) throw new InvalidOperationException("Audio buffer queue failed (winmm " + mm + ").");
            _slots.Add(slot);
        }

        private void WaveInCallback(IntPtr hwi, uint msg, UIntPtr instance, IntPtr param1, IntPtr param2)
        {
            if (msg != Native.WIM_DATA || param1 == IntPtr.Zero) return;
            try
            {
                var hdr = (Native.WAVEHDR)Marshal.PtrToStructure(param1, typeof(Native.WAVEHDR));
                if (hdr.dwBytesRecorded > 0)
                {
                    byte[] data = new byte[hdr.dwBytesRecorded];
                    Marshal.Copy(hdr.lpData, data, 0, data.Length);
                    lock (_gate)
                    {
                        if (_capturing) _pcm.Write(data, 0, data.Length);
                        else if (_monitoring) AddToPreRoll(data);
                    }
                }

                lock (_gate)
                {
                    if (_monitoring && _waveIn != IntPtr.Zero)
                    {
                        hdr.dwBytesRecorded = 0;
                        Marshal.StructureToPtr(hdr, param1, false);
                        Native.waveInAddBuffer(_waveIn, param1, (uint)Marshal.SizeOf(typeof(Native.WAVEHDR)));
                    }
                }
            }
            catch
            {
                // Never throw through a native callback boundary.
            }
        }

        private void AddToPreRoll(byte[] data)
        {
            if (data == null || data.Length == 0 || _preRoll.Length == 0) return;
            int offset = Math.Max(0, data.Length - _preRoll.Length);
            for (int i = offset; i < data.Length; i++)
            {
                _preRoll[_preRollWrite] = data[i];
                _preRollWrite = (_preRollWrite + 1) % _preRoll.Length;
                if (_preRollCount < _preRoll.Length) _preRollCount++;
            }
        }

        private void CopyPreRollTo(Stream destination)
        {
            if (_preRollCount <= 0) return;
            int start = (_preRollWrite - _preRollCount + _preRoll.Length) % _preRoll.Length;
            int first = Math.Min(_preRollCount, _preRoll.Length - start);
            destination.Write(_preRoll, start, first);
            int remaining = _preRollCount - first;
            if (remaining > 0) destination.Write(_preRoll, 0, remaining);
        }

        private void SafeNativeClose(bool stopAndReset = true)
        {
            if (_waveIn == IntPtr.Zero) return;
            IntPtr handle = _waveIn;
            bool cleanupOk = true;

            // Never hold _gate across stop/reset: either call this outside _gate, or
            // pass false during StartMonitor failure cleanup before capture actually starts.
            if (stopAndReset)
            {
                try { Native.waveInStop(handle); } catch { cleanupOk = false; }
                try { Native.waveInReset(handle); } catch { cleanupOk = false; }
            }

            foreach (var slot in _slots)
            {
                try
                {
                    uint mm = Native.waveInUnprepareHeader(handle, slot.Header, (uint)Marshal.SizeOf(typeof(Native.WAVEHDR)));
                    if (mm != 0) cleanupOk = false;
                }
                catch { cleanupOk = false; }
            }
            try
            {
                if (Native.waveInClose(handle) != 0) cleanupOk = false;
            }
            catch { cleanupOk = false; }

            _waveIn = IntPtr.Zero;
            if (cleanupOk)
            {
                foreach (var slot in _slots)
                {
                    if (slot.Header != IntPtr.Zero) Marshal.FreeHGlobal(slot.Header);
                    if (slot.Data != IntPtr.Zero) Marshal.FreeHGlobal(slot.Data);
                }
                _slots.Clear();
            }
            else
            {
                // Deliberately retain unmanaged buffers + rooted callback until process exit.
                // A rare native teardown failure must leak bounded memory, not risk use-after-free.
                _nativeCleanupFailed = true;
            }
        }

        public void Dispose()
        {
            lock (_gate)
            {
                if (_disposed) return;
                _disposed = true;
                _capturing = false;
                _monitoring = false;
            }

            SafeNativeClose();
            if (!_nativeCleanupFailed) _pcm.Dispose();
        }
    }

    internal static class Wav
    {
        public static byte[] WrapPcm16Mono16k(byte[] pcm)
        {
            using (var ms = new MemoryStream())
            using (var bw = new BinaryWriter(ms, Encoding.ASCII, true))
            {
                bw.Write(Encoding.ASCII.GetBytes("RIFF"));
                bw.Write(36 + pcm.Length);
                bw.Write(Encoding.ASCII.GetBytes("WAVE"));
                bw.Write(Encoding.ASCII.GetBytes("fmt "));
                bw.Write(16);
                bw.Write((short)1);
                bw.Write((short)1);
                bw.Write(16000);
                bw.Write(32000);
                bw.Write((short)2);
                bw.Write((short)16);
                bw.Write(Encoding.ASCII.GetBytes("data"));
                bw.Write(pcm.Length);
                bw.Write(pcm);
                bw.Flush();
                return ms.ToArray();
            }
        }
    }

    internal enum OverlayMode
    {
        Listening,
        Processing,
        Pasted,
        Copied,
        NoSpeech,
        Error
    }

    internal sealed class AudioOverlayForm : Form
    {
        private const int WS_EX_TRANSPARENT = 0x00000020;
        private const int WS_EX_TOOLWINDOW = 0x00000080;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WM_NCHITTEST = 0x0084;
        private const int HTTRANSPARENT = -1;
        private readonly System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();
        private OverlayMode _mode = OverlayMode.Listening;
        private int _tick;
        private int _autoHideTick = -1;

        public AudioOverlayForm()
        {
            Text = "SignalFlow Mini Activity";
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            Width = 272;
            Height = 76;
            BackColor = System.Drawing.Color.FromArgb(22, 22, 26);
            ForeColor = System.Drawing.Color.White;
            Opacity = 0.92;
            DoubleBuffered = true;

            _timer.Interval = 50;
            _timer.Tick += (s, e) =>
            {
                _tick++;
                if (_autoHideTick >= 0 && _tick >= _autoHideTick)
                {
                    HideOverlay();
                    return;
                }
                Invalidate();
            };
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WS_EX_NOACTIVATE | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW;
                return cp;
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_NCHITTEST)
            {
                m.Result = (IntPtr)HTTRANSPARENT;
                return;
            }
            base.WndProc(ref m);
        }

        public void ShowListening(IntPtr targetWindow)
        {
            _mode = OverlayMode.Listening;
            ShowState(targetWindow, -1);
        }

        public void ShowProcessing(IntPtr targetWindow)
        {
            _mode = OverlayMode.Processing;
            ShowState(targetWindow, -1);
        }

        public void ShowOutcome(IntPtr targetWindow, bool pasted, bool error)
        {
            _mode = error ? OverlayMode.Error : (pasted ? OverlayMode.Pasted : OverlayMode.Copied);
            ShowState(targetWindow, error ? 1200 : (pasted ? 420 : 950));
        }

        public void ShowNoSpeech(IntPtr targetWindow)
        {
            _mode = OverlayMode.NoSpeech;
            ShowState(targetWindow, 700);
        }

        private void ShowState(IntPtr targetWindow, int autoHideMilliseconds)
        {
            PositionNearTarget(targetWindow);
            _autoHideTick = autoHideMilliseconds > 0 ? _tick + Math.Max(1, autoHideMilliseconds / _timer.Interval) : -1;
            if (!Visible) Show();
            _timer.Start();
            Invalidate();
        }

        private void PositionNearTarget(IntPtr targetWindow)
        {
            Screen screen = targetWindow != IntPtr.Zero && Native.IsWindow(targetWindow)
                ? Screen.FromHandle(targetWindow)
                : Screen.PrimaryScreen;
            System.Drawing.Rectangle work = screen.WorkingArea;
            Left = work.Left + Math.Max(0, (work.Width - Width) / 2);
            Top = work.Bottom - Height - 24;
        }

        public void HideOverlay()
        {
            _autoHideTick = -1;
            _timer.Stop();
            if (Visible) Hide();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            using (var border = new System.Drawing.Pen(System.Drawing.Color.FromArgb(95, 255, 255, 255), 1f))
                e.Graphics.DrawRectangle(border, 0, 0, Width - 1, Height - 1);

            int centerY = Height / 2;
            for (int i = 0; i < 7; i++)
            {
                double phase = (_tick * 0.42) + (i * 0.78);
                double energy = _mode == OverlayMode.Listening
                    ? 0.35 + (0.65 * Math.Abs(Math.Sin(phase)))
                    : _mode == OverlayMode.Processing
                        ? 0.20 + (0.45 * Math.Abs(Math.Sin(phase * 0.72)))
                        : 0.22;
                int h = 8 + (int)(30 * energy);
                int x = 22 + (i * 12);
                using (var brush = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(230, 238, 238, 242)))
                    e.Graphics.FillRectangle(brush, x, centerY - (h / 2), 7, h);
            }

            string label;
            switch (_mode)
            {
                case OverlayMode.Listening: label = "Listening"; break;
                case OverlayMode.Processing: label = "Transcribing locally"; break;
                case OverlayMode.Pasted: label = "Pasted"; break;
                case OverlayMode.Copied: label = "Copied to clipboard"; break;
                case OverlayMode.NoSpeech: label = "No speech detected"; break;
                default: label = "SignalFlow Mini error"; break;
            }

            using (var font = new System.Drawing.Font("Segoe UI", 10.5f, System.Drawing.FontStyle.Bold))
            using (var brush = new System.Drawing.SolidBrush(System.Drawing.Color.White))
                e.Graphics.DrawString(label, font, brush, 122, 27);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _timer.Dispose();
            base.Dispose(disposing);
        }
    }

    internal sealed class SignalFlowMiniHostForm : Form
    {
        private const int WS_EX_APPWINDOW = 0x00040000;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int PostRollMilliseconds = 650;
        private readonly object _stateGate = new object();
        private readonly string _appDir;
        private readonly string _whisperExe;
        private readonly string _model;
        private readonly AudioOverlayForm _overlay = new AudioOverlayForm();
        private Native.LowLevelKeyboardProc _hookProc;
        private IntPtr _hook;
        private AudioRecorder _recorder;
        private System.Drawing.Icon _appIcon;
        private DateTime _startedAt;
        private bool _f8Down;
        private bool _busy;
        private bool _capturing;
        private IntPtr _targetWindow;
        private IntPtr _targetControl;

        public SignalFlowMiniHostForm()
        {
            _appDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
            _whisperExe = Path.Combine(_appDir, "runtime", "whisper", "whisper-cli.exe");
            _model = Path.Combine(_appDir, "models", "ggml-small.en.bin");

            // Persistent taskbar host only. It remains a visible top-level application
            // window for taskbar identity, but it is 1x1, off-screen, nearly transparent,
            // and marked NOACTIVATE so it cannot become the text/caret target.
            Text = "SignalFlow Mini - Ready";
            Width = 1;
            Height = 1;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = true;
            StartPosition = FormStartPosition.Manual;
            Location = new System.Drawing.Point(-32000, -32000);
            Opacity = 0.01;
            ControlBox = false;
            MinimizeBox = false;
            MaximizeBox = false;

            string iconPath = Path.Combine(_appDir, "assets", "Signalproof.ico");
            if (File.Exists(iconPath))
            {
                try
                {
                    _appIcon = new System.Drawing.Icon(iconPath);
                    Icon = _appIcon;
                }
                catch { }
            }

            Shown += (s, e) =>
            {
                InstallKeyboardHook();
                PrimeMicrophoneMonitor();
            };
            FormClosed += (s, e) => Cleanup();
        }

        protected override bool ShowWithoutActivation { get { return true; } }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WS_EX_APPWINDOW | WS_EX_NOACTIVATE;
                return cp;
            }
        }

        private void PrimeMicrophoneMonitor()
        {
            lock (_stateGate)
            {
                if (_recorder != null) return;
                try
                {
                    _recorder = new AudioRecorder();
                    _recorder.StartMonitor();
                    SetStatus("Ready");
                }
                catch (Exception ex)
                {
                    try { if (_recorder != null) _recorder.Dispose(); } catch { }
                    _recorder = null;
                    SetStatus("Microphone error");
                    Debug.WriteLine(ex);
                }
            }
        }

        private void InstallKeyboardHook()
        {
            _hookProc = KeyboardHook;
            using (Process cur = Process.GetCurrentProcess())
            using (ProcessModule mod = cur.MainModule)
            {
                _hook = Native.SetWindowsHookEx(Native.WH_KEYBOARD_LL, _hookProc, Native.GetModuleHandle(mod.ModuleName), 0);
            }
            if (_hook == IntPtr.Zero) SetStatus("F8 hook unavailable");
        }

        private IntPtr KeyboardHook(int code, IntPtr wParam, IntPtr lParam)
        {
            if (code >= 0)
            {
                var k = (Native.KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(Native.KBDLLHOOKSTRUCT));
                if (k.vkCode == Native.VK_F8)
                {
                    int msg = wParam.ToInt32();
                    if ((msg == Native.WM_KEYDOWN || msg == Native.WM_SYSKEYDOWN) && !_f8Down)
                    {
                        _f8Down = true;
                        BeginInvoke((Action)(() => BeginCapture()));
                        return (IntPtr)1;
                    }
                    if ((msg == Native.WM_KEYUP || msg == Native.WM_SYSKEYUP) && _f8Down)
                    {
                        _f8Down = false;
                        BeginInvoke((Action)(() => EndCaptureAsync()));
                        return (IntPtr)1;
                    }
                }
            }
            return Native.CallNextHookEx(_hook, code, wParam, lParam);
        }

        private void CapturePasteTarget()
        {
            _targetWindow = Native.GetForegroundWindow();
            _targetControl = IntPtr.Zero;
            if (_targetWindow == IntPtr.Zero || _targetWindow == Handle) return;
            uint ignoredProcessId;
            uint thread = Native.GetWindowThreadProcessId(_targetWindow, out ignoredProcessId);
            var gti = new Native.GUITHREADINFO();
            gti.cbSize = Marshal.SizeOf(typeof(Native.GUITHREADINFO));
            if (Native.GetGUIThreadInfo(thread, ref gti)) _targetControl = gti.hwndFocus;
        }

        private void BeginCapture()
        {
            lock (_stateGate)
            {
                if (_busy || _capturing) return;
                try
                {
                    CapturePasteTarget();
                    if (_recorder == null)
                    {
                        _recorder = new AudioRecorder();
                        _recorder.StartMonitor();
                    }
                    _recorder.BeginCapture(); // includes the 500 ms rolling in-memory pre-roll.
                    _capturing = true;
                    _startedAt = DateTime.UtcNow;
                    SetStatus("Listening");
                    _overlay.ShowListening(_targetWindow);
                }
                catch (Exception ex)
                {
                    _capturing = false;
                    try { if (_recorder != null) _recorder.Dispose(); } catch { }
                    _recorder = null;
                    SetStatus("Microphone error");
                    _overlay.ShowOutcome(_targetWindow, false, true);
                    Debug.WriteLine(ex);
                }
            }
        }

        private async void EndCaptureAsync()
        {
            AudioRecorder recorder;
            TimeSpan held;
            lock (_stateGate)
            {
                if (!_capturing || _recorder == null) return;
                recorder = _recorder;
                _capturing = false;
                held = DateTime.UtcNow - _startedAt;
                _busy = true;
            }

            byte[] pcm = new byte[0];
            try
            {
                SetStatus("Finishing last word");
                _overlay.ShowProcessing(_targetWindow);
                await Task.Delay(PostRollMilliseconds);
                pcm = recorder.EndCapture();
            }
            catch (Exception ex)
            {
                SetStatus("Capture error");
                _overlay.ShowOutcome(_targetWindow, false, true);
                Debug.WriteLine(ex);
            }

            if (held.TotalMilliseconds < 220)
            {
                SetStatus("Ready");
                _overlay.HideOverlay();
                FinishBusy();
                return;
            }

            if (pcm.Length < 6400)
            {
                SetStatus("No speech captured");
                _overlay.ShowNoSpeech(_targetWindow);
                FinishBusy();
                return;
            }

            try
            {
                SetStatus("Transcribing locally");
                _overlay.ShowProcessing(_targetWindow);
                string text = await Task.Run(() => Transcribe(pcm));
                if (string.IsNullOrWhiteSpace(text))
                {
                    SetStatus("No speech detected");
                    _overlay.ShowNoSpeech(_targetWindow);
                    return;
                }

                Clipboard.SetText(text); // recoverability contract: clipboard is authoritative even if paste fails.
                bool pasted = PasteToCapturedTarget();
                SetStatus(pasted ? "Ready" : "Copied to clipboard");
                _overlay.ShowOutcome(_targetWindow, pasted, false);
            }
            catch (OperationCanceledException)
            {
                SetStatus("Ready");
                _overlay.HideOverlay();
            }
            catch (Exception ex)
            {
                SetStatus("Transcription error");
                _overlay.ShowOutcome(_targetWindow, false, true);
                Debug.WriteLine(ex);
            }
            finally
            {
                FinishBusy();
            }
        }

        private void FinishBusy()
        {
            lock (_stateGate) _busy = false;
        }

        private string Transcribe(byte[] pcm)
        {
            if (!File.Exists(_whisperExe)) throw new FileNotFoundException("whisper-cli missing. Run install.ps1.", _whisperExe);
            if (!File.Exists(_model)) throw new FileNotFoundException("Whisper model missing. Run install.ps1.", _model);

            string tmpDir = Path.Combine(Path.GetTempPath(), "SignalFlow-Mini");
            Directory.CreateDirectory(tmpDir);
            string wavPath = Path.Combine(tmpDir, "capture-" + Guid.NewGuid().ToString("N") + ".wav");
            try
            {
                File.WriteAllBytes(wavPath, Wav.WrapPcm16Mono16k(pcm));
                var psi = new ProcessStartInfo
                {
                    FileName = _whisperExe,
                    Arguments = "-m \"" + _model + "\" -f \"" + wavPath + "\" -l en -nt -np",
                    WorkingDirectory = Path.GetDirectoryName(_whisperExe),
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                using (var p = Process.Start(psi))
                {
                    string stdout = p.StandardOutput.ReadToEnd();
                    string stderr = p.StandardError.ReadToEnd();
                    if (!p.WaitForExit(120000))
                    {
                        try { p.Kill(); } catch { }
                        throw new TimeoutException("Local recognizer exceeded 120 seconds.");
                    }
                    if (p.ExitCode != 0)
                    {
                        string detail = (stderr ?? "").Trim();
                        if (detail.Length > 240) detail = detail.Substring(detail.Length - 240);
                        throw new InvalidOperationException("whisper-cli failed (" + p.ExitCode + "): " + detail);
                    }
                    return NormalizeTranscript(stdout);
                }
            }
            finally
            {
                try { if (File.Exists(wavPath)) File.Delete(wavPath); } catch { }
            }
        }

        private static string NormalizeTranscript(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return "";
            var lines = raw.Replace("\r", "").Split('\n');
            var kept = new List<string>();
            foreach (string source in lines)
            {
                string line = source.Trim();
                if (line.Length == 0) continue;
                if (line.StartsWith("whisper_", StringComparison.OrdinalIgnoreCase)) continue;
                if (line.StartsWith("system_info", StringComparison.OrdinalIgnoreCase)) continue;
                if (line.StartsWith("main:", StringComparison.OrdinalIgnoreCase)) continue;
                line = Regex.Replace(line, @"^\[[0-9:.]+\s*-->\s*[0-9:.]+\]\s*", "");
                if (line.Length > 0) kept.Add(line);
            }
            return string.Join(" ", kept).Trim();
        }

        private bool PasteToCapturedTarget()
        {
            if (_targetWindow == IntPtr.Zero || _targetWindow == Handle || !Native.IsWindow(_targetWindow)) return false;

            // Never redirect focus and never paste into a different foreground window.
            // The transcript is already on the clipboard, so a safety refusal is recoverable.
            if (Native.GetForegroundWindow() != _targetWindow) return false;

            IntPtr focusedNow = GetFocusedControl(_targetWindow);
            if (_targetControl != IntPtr.Zero && focusedNow != IntPtr.Zero && focusedNow != _targetControl) return false;

            IntPtr target = _targetControl != IntPtr.Zero ? _targetControl : _targetWindow;
            string targetClass = WindowClass(target);

            // Native Edit/RichEdit controls accept WM_PASTE directly. Chromium/Electron
            // renderers generally do not, so use Ctrl+V only while the originally captured
            // window/control is still the active target. This avoids wrong-window paste.
            if (IsClassicPasteControl(targetClass))
            {
                UIntPtr result;
                IntPtr ok = Native.SendMessageTimeout(target, Native.WM_PASTE, UIntPtr.Zero, IntPtr.Zero, Native.SMTO_ABORTIFHUNG, 2000, out result);
                return ok != IntPtr.Zero;
            }

            return SendGuardedCtrlV();
        }

        private static IntPtr GetFocusedControl(IntPtr window)
        {
            if (window == IntPtr.Zero || !Native.IsWindow(window)) return IntPtr.Zero;
            uint ignoredProcessId;
            uint thread = Native.GetWindowThreadProcessId(window, out ignoredProcessId);
            var gti = new Native.GUITHREADINFO();
            gti.cbSize = Marshal.SizeOf(typeof(Native.GUITHREADINFO));
            return Native.GetGUIThreadInfo(thread, ref gti) ? gti.hwndFocus : IntPtr.Zero;
        }

        private static string WindowClass(IntPtr hwnd)
        {
            if (hwnd == IntPtr.Zero) return "";
            var sb = new StringBuilder(256);
            return Native.GetClassName(hwnd, sb, sb.Capacity) > 0 ? sb.ToString() : "";
        }

        private static bool IsClassicPasteControl(string className)
        {
            if (string.IsNullOrEmpty(className)) return false;
            return className.Equals("Edit", StringComparison.OrdinalIgnoreCase) ||
                   className.StartsWith("RichEdit", StringComparison.OrdinalIgnoreCase);
        }

        private bool SendGuardedCtrlV()
        {
            if (Native.GetForegroundWindow() != _targetWindow) return false;
            IntPtr focusedNow = GetFocusedControl(_targetWindow);
            if (_targetControl != IntPtr.Zero && focusedNow != IntPtr.Zero && focusedNow != _targetControl) return false;

            var inputs = new Native.INPUT[]
            {
                KeyInput(Native.VK_CONTROL, false),
                KeyInput(Native.VK_V, false),
                KeyInput(Native.VK_V, true),
                KeyInput(Native.VK_CONTROL, true)
            };
            return Native.SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(Native.INPUT))) == (uint)inputs.Length;
        }

        private static Native.INPUT KeyInput(ushort vk, bool keyUp)
        {
            return new Native.INPUT
            {
                type = Native.INPUT_KEYBOARD,
                U = new Native.InputUnion
                {
                    ki = new Native.KEYBDINPUT
                    {
                        wVk = vk,
                        wScan = 0,
                        dwFlags = keyUp ? Native.KEYEVENTF_KEYUP : 0,
                        time = 0,
                        dwExtraInfo = UIntPtr.Zero
                    }
                }
            };
        }

        private void SetStatus(string text)
        {
            if (InvokeRequired) { BeginInvoke((Action)(() => SetStatus(text))); return; }
            Text = "SignalFlow Mini - " + text;
        }

        private void Cleanup()
        {
            try { _overlay.HideOverlay(); } catch { }
            try { _overlay.Dispose(); } catch { }
            try { if (_hook != IntPtr.Zero) Native.UnhookWindowsHookEx(_hook); } catch { }
            try { if (_recorder != null) _recorder.Dispose(); } catch { }
            try { if (_appIcon != null) _appIcon.Dispose(); } catch { }
        }
    }

    internal static class Program
    {
        private const string MutexName = "Local\\SignalFlow-Mini-v1";

        [STAThread]
        private static void Main()
        {
            bool created;
            using (var mutex = new Mutex(true, MutexName, out created))
            {
                if (!created)
                {
                    MessageBox.Show("SignalFlow Mini is already running.", "SignalFlow Mini", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string pidFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SignalFlow-Mini", "signalflow-mini.pid");
                Directory.CreateDirectory(Path.GetDirectoryName(pidFile));
                File.WriteAllText(pidFile, Process.GetCurrentProcess().Id.ToString());
                try
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new SignalFlowMiniHostForm());
                }
                finally
                {
                    try
                    {
                        if (File.Exists(pidFile) && File.ReadAllText(pidFile).Trim() == Process.GetCurrentProcess().Id.ToString())
                            File.Delete(pidFile);
                    }
                    catch { }
                }
            }
        }
    }
}
